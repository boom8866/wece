#!/bin/bash
perl -wpi -e "s/\t/    /g" $1
